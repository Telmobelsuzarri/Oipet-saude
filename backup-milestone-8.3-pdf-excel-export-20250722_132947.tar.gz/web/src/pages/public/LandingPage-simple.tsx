import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuthStore } from '@/stores/authStore'

export const LandingPage: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuthStore()

  const handleClearSession = () => {
    logout()
    window.location.reload()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            OiPet Saúde
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Plataforma completa para monitoramento de saúde e bem-estar dos seus pets
          </p>
          
          {/* Debug info */}
          {isAuthenticated && (
            <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-6">
              <p className="mb-2">
                <strong>Debug:</strong> Você já está logado como: {user?.name} ({user?.email})
                {user?.isAdmin && " (ADMIN)"}
              </p>
              <div className="flex gap-2 justify-center">
                <Link
                  to="/app/dashboard"
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                >
                  Ir para Dashboard
                </Link>
                <button
                  onClick={handleClearSession}
                  className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                >
                  Sair / Limpar Sessão
                </button>
              </div>
            </div>
          )}
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/auth/register"
              className="inline-flex items-center px-8 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-lg font-medium hover:from-red-600 hover:to-red-700 transition-all duration-200"
            >
              Começar Agora
            </Link>
            <Link
              to="/auth/login"
              className="inline-flex items-center px-8 py-3 bg-white text-red-600 rounded-lg font-medium border-2 border-red-500 hover:bg-red-50 transition-all duration-200"
            >
              Fazer Login
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}