function App() {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1>🐾 OiPet Saúde - Teste Funcionando!</h1>
      <p>Servidor carregando corretamente</p>
      <button style={{ padding: '10px 20px', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px' }}>
        Teste de Botão
      </button>
    </div>
  )
}

export default App