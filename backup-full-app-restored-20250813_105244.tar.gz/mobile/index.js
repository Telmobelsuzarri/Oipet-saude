/**
 * Entry point para o OiPet Saúde Mobile App
 */

import { registerRootComponent } from 'expo';
import App from './App';

// Registrar o componente principal
registerRootComponent(App);