"use strict";
/**
 * Tipos TypeScript compartilhados entre todas as plataformas
 */
Object.defineProperty(exports, "__esModule", { value: true });
